# LCMA Smart Student Housing Prototype (Stage 2)

A working prototype of the LCMA housing platform: two user roles, a real SQL database with create / read / update / delete,
simulated IoT telemetry with two automatic rules, and working security steps. **No npm install needed.**

## Run it (2 minutes)
**Windows, easiest:** extract the zip to a normal folder such as `C:\lcma-prototype` (not inside OneDrive), then **double-click `start.bat`**. It checks your computer, starts the app and shows any problem in plain words. Then open http://localhost:3000.
If anything fails, run `node tools/doctor.mjs` and read the PROBLEM lines.

Manual start:
Requirement: **Node.js 22.13 or newer** (`node -v`). No other software.

```bash
cd lcma-prototype
node server.js          # or: npm start
```
Open **http://localhost:3000**. The database file `lcma.db` is created and seeded on first start. Delete it to reset the demo.

| Role | Email | Password |
|---|---|---|
| Admin (housing staff) | admin@lcma.kz | Admin#2026demo |
| Student | student1@lcma.kz | Student#2026demo |
| Student | student2@lcma.kz | Student#2026demo |

Run the automated checks (starts its own server and temporary database): `npm test` -> 37 checks.

## What the prototype shows
| Task requirement | Where |
|---|---|
| Screens for 2 roles | Student: rooms, apply, my booking. Admin: Dashboard, Bookings, Rooms, Alerts, Security tabs |
| Database CRUD on 3+ tables | `room` (create/edit/delete), `booking` (apply, approve/reject, cancel/delete), `telemetry_event` + `access_event` + `alert` (inserted by sensors and rules, read by dashboard) |
| Smart feature (chart + rules) | Live chart per room (simulated sensors). Rule 1 and Rule 2 below |
| Security step | Role sign-in, hashed passwords, token checks, input validation, parameterized SQL, rate limit |

### Smart rules
1. **Climate:** IF a room reports 0 people for 30+ minutes THEN HVAC switches to ECO (19 C). Occupancy returns -> NORMAL (21 C).
   Sensor failure: no new readings means no change (HVAC stays as it was) and the dashboard "Last reading" time stops moving.
2. **Access:** IF more than 3 denied scans in 5 minutes THEN the reader is locked and a security alert is created. Admin unlocks it.

### Security steps (and how to test each live)
| Step | Test |
|---|---|
| Passwords stored as salted scrypt hashes | `sqlite3 lcma.db "select email,password_hash from app_user"` shows `scrypt$...`, never the password |
| Role checks on the server | Sign in as student, press **Call admin endpoint** -> HTTP 403 |
| Signed tokens (HS256), 1 h expiry | A modified token returns 401 (covered by `npm test`) |
| Input validation + parameterized SQL | Admin -> Security -> **Send ' OR 1=1 --** -> HTTP 400, no token |
| Rate limit | 5 wrong passwords in a minute -> HTTP 429 |
| Output escaping, CSP and security headers | All user text is escaped; CSP blocks inline scripts; HSTS is added behind HTTPS |

## Put it online and share a QR code
See **DEPLOY.md** (Render, Fly.io or your own server with Docker). Then: `node tools/qr.mjs https://your-link lcma-qr` creates the QR code image.
The interface is phone-friendly, so visitors can scan, sign in as a student and try the app on their own device.

## Demo script (12-15 min, four presenters)
1. **Miras (database):** student applies (CREATE booking), admin approves (UPDATE), admin deletes (DELETE), Rooms tab adds a room. Show the row in `lcma.db`.
2. **Diar (security):** the table above: hash in the database, 403 test, injection test, 6 wrong passwords -> 429.
3. **Dauren (screens):** walk through both roles; show full room, one-open-booking rule, validation messages.
4. **Dias (smart rules):** Dashboard live chart; Security tab -> **Simulate empty room**, watch ECO; press **Denied card** 4 times, reader locks, alert appears.

## Project layout
```
server.js        API + static server (routes, validation, roles, SSE stream)
lib/auth.js      scrypt hashing, HS256 tokens        lib/rules.js  the two smart rules
lib/db.js        database open + seed data           lib/sim.js    telemetry simulator
schema.sql       6 tables (see docs/DESIGN_NOTES.md) public/       front end (HTML, CSS, JS)
test/test.mjs    37 end-to-end checks
tools/qr.mjs     QR code generator (no dependencies)
Dockerfile, render.yaml, fly.toml, docker-compose.yml   deployment (see DEPLOY.md)
```

## Real vs simulated vs not done
| Part | Status |
|---|---|
| SQL database, CRUD, constraints, transactions | Real (SQLite) |
| Sign-in, roles, hashing, tokens, validation | Real |
| Rules engine, live updates, chart | Real |
| Sensor readings (occupancy, temperature) | **Simulated** by `lib/sim.js` |
| NFC door reader | **Simulated** by the Security tab buttons |
| University SSO (OpenID Connect) | **Not done** (local accounts instead) |
| MFA, cloud hosting, backups, real hardware | **Not done** |
