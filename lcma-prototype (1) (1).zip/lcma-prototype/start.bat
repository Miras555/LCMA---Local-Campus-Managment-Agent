@echo off
rem Double-click to start LCMA. Works from any folder because it first moves into its own folder.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b 1
)
node tools\doctor.mjs
if errorlevel 1 (
  pause
  exit /b 1
)
echo.
echo Starting LCMA... open http://localhost:3000 in your browser. Press Ctrl+C to stop.
node server.js
pause
