// LCMA prototype API + static server. Zero npm dependencies (Node >= 22.13: node:http, node:sqlite, node:crypto).
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifyPassword, hashPassword, signToken, verifyToken } from './lib/auth.js';
import { ingestTelemetry, recordScan } from './lib/rules.js';
import { startSimulator, control } from './lib/sim.js';

const [nMaj, nMin] = process.versions.node.split('.').map(Number);
if (nMaj < 22 || (nMaj === 22 && nMin < 13)) { console.error(`Node.js ${process.versions.node} is too old. Install Node 22.13 or newer from https://nodejs.org and try again.`); process.exit(1); }
const { openDb } = await import('./lib/db.js'); // loaded after the version check so old Node versions get a clear message
const PORT = +process.env.PORT || 3000;
const DEVICE_KEY = process.env.LCMA_DEVICE_KEY || 'demo-device-key';
const HOST = process.env.HOST; // unset = listen on IPv4 and IPv6, so http://localhost works on every system
const TRUST_PROXY = process.env.LCMA_TRUST_PROXY === '1';           // set behind Render / Fly / Caddy so rate limits see the real client IP
const DEMO_HINT = ['all', 'student', 'none'].includes(process.env.LCMA_DEMO_HINT) ? process.env.LCMA_DEMO_HINT : 'all'; // which demo logins the sign-in page shows
const PUBLIC = fileURLToPath(new URL('./public/', import.meta.url));
const DB_FILE = process.env.DB_PATH || 'lcma.db';
let db;
try { db = openDb(DB_FILE); } catch (e) {
  console.error(`\nCould not open the database file "${DB_FILE}".\n${e.message}\nTip: run the app from a normal folder (not inside OneDrive), or set another location, e.g. in cmd:  set DB_PATH=C:\\lcma-data\\lcma.db`);
  process.exit(1);
}
const clients = new Set();
const emit = (type, data) => { const m = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`; for (const c of clients) c.write(m); };

// ---------- input validation (Assignment 3: validate input, parameterize SQL) ----------
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m) => new HttpError(400, m);
const EMAIL = /^[^\s@<>'"`;]+@[^\s@<>'"`;]+\.[^\s@<>'"`;]+$/;
const int = (v, n, min, max) => { if (!Number.isInteger(v) || v < min || v > max) throw bad(`${n} must be a whole number ${min}-${max}`); return v; };
const text = (v, n, re, hint) => { if (typeof v !== 'string' || !re.test(v.trim())) throw bad(`${n} must be ${hint}`); return v.trim(); };
const oneOf = (v, n, list) => { if (!list.includes(v)) throw bad(`${n} must be one of: ${list.join(', ')}`); return v; };
const ROOMNO = /^[A-Za-z0-9-]{1,12}$/, HALL = /^[\p{L}\p{N} .-]{2,40}$/u;

// ---------- sign-in with rate limit ----------
const fails = new Map();
const DUMMY = hashPassword('not-a-real-password');
function login(body, ip) {
  const email = text(body.email, 'email', EMAIL, 'a valid email address').toLowerCase();
  if (typeof body.password !== 'string' || body.password.length < 1 || body.password.length > 200) throw bad('password is required');
  const key = ip + '|' + email, f = fails.get(key);
  if (f && f.n >= 5 && Date.now() - f.t < 60000) throw new HttpError(429, 'Too many attempts. Wait one minute.');
  const u = db.prepare('SELECT * FROM app_user WHERE email=?').get(email);
  const ok = verifyPassword(body.password, u ? u.password_hash : DUMMY) && u; // dummy hash keeps timing similar
  if (!ok) { fails.set(key, { n: (f && Date.now() - f.t < 60000 ? f.n : 0) + 1, t: Date.now() }); throw new HttpError(401, 'Invalid email or password'); }
  fails.delete(key);
  return { token: signToken({ sub: u.user_id, role: u.role, name: u.display_name }), user: { user_id: u.user_id, email: u.email, display_name: u.display_name, role: u.role } };
}

// ---------- routes ----------
const routes = [];
const route = (method, path, auth, fn) => routes.push({ method, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), auth, fn });
const roomRows = () => db.prepare(`SELECT r.*, (SELECT COUNT(*) FROM booking b WHERE b.room_id=r.room_id AND b.status='approved') approved,
  (SELECT COUNT(*) FROM booking b WHERE b.room_id=r.room_id AND b.status='pending') pending FROM room r ORDER BY room_number`).all()
  .map((r) => ({ ...r, free_beds: r.capacity - r.approved }));
const uniqueHit = (e) => /UNIQUE constraint failed/.test(e.message);

route('GET', '/api/config', null, () => [200, { demo_hint: DEMO_HINT }]);
route('POST', '/api/login', null, ({ body, ip }) => [200, login(body, ip)]);
route('GET', '/api/me', 'any', ({ user }) => [200, db.prepare('SELECT user_id,email,display_name,role FROM app_user WHERE user_id=?').get(user.sub)]);

// ROOM: create / read / update / delete
route('GET', '/api/rooms', 'any', () => [200, roomRows()]);
route('POST', '/api/rooms', 'admin', ({ body }) => {
  const v = [text(body.room_number, 'room_number', ROOMNO, 'letters, digits or dashes (max 12)'), text(body.hall, 'hall', HALL, 'letters, digits and spaces (2-40)'),
    int(body.capacity, 'capacity', 1, 6), int(body.price_kzt, 'price_kzt', 1, 1000000)];
  try { const r = db.prepare('INSERT INTO room(room_number,hall,capacity,price_kzt) VALUES(?,?,?,?)').run(...v); return [201, { room_id: Number(r.lastInsertRowid) }]; }
  catch (e) { if (uniqueHit(e)) throw new HttpError(409, 'Room number already exists'); throw e; }
});
route('PATCH', '/api/rooms/:id', 'admin', ({ params, body }) => {
  const id = int(+params.id, 'id', 1, 1e9), sets = [], vals = [];
  const add = (c, v) => { sets.push(c + '=?'); vals.push(v); };
  if ('room_number' in body) add('room_number', text(body.room_number, 'room_number', ROOMNO, 'letters, digits or dashes'));
  if ('hall' in body) add('hall', text(body.hall, 'hall', HALL, 'letters, digits and spaces'));
  if ('capacity' in body) add('capacity', int(body.capacity, 'capacity', 1, 6));
  if ('price_kzt' in body) add('price_kzt', int(body.price_kzt, 'price_kzt', 1, 1000000));
  if ('reader_locked' in body) add('reader_locked', int(body.reader_locked, 'reader_locked', 0, 1));
  if (!sets.length) throw bad('nothing to update');
  try { const r = db.prepare(`UPDATE room SET ${sets.join(',')} WHERE room_id=?`).run(...vals, id); if (!r.changes) throw new HttpError(404, 'Room not found'); }
  catch (e) { if (uniqueHit(e)) throw new HttpError(409, 'Room number already exists'); throw e; }
  emit('room', { room_id: id }); return [200, { ok: true }];
});
route('DELETE', '/api/rooms/:id', 'admin', ({ params }) => {
  const r = db.prepare('DELETE FROM room WHERE room_id=?').run(int(+params.id, 'id', 1, 1e9));
  if (!r.changes) throw new HttpError(404, 'Room not found'); emit('room', {}); return [200, { ok: true }];
});

// BOOKING: create / read / update / delete
route('GET', '/api/bookings', 'any', ({ user }) => {
  const base = 'SELECT b.*, r.room_number, r.hall, u.display_name, u.email FROM booking b JOIN room r ON r.room_id=b.room_id JOIN app_user u ON u.user_id=b.user_id';
  return [200, user.role === 'admin' ? db.prepare(base + ' ORDER BY b.booking_id DESC').all() : db.prepare(base + ' WHERE b.user_id=? ORDER BY b.booking_id DESC').all(user.sub)];
});
route('POST', '/api/bookings', 'student', ({ user, body }) => {
  const room_id = int(body.room_id, 'room_id', 1, 1e9), desk = oneOf(body.desk_preference || 'window', 'desk_preference', ['window', 'wall']);
  const room = roomRows().find((r) => r.room_id === room_id);
  if (!room) throw new HttpError(404, 'Room not found');
  if (room.free_beds < 1) throw new HttpError(409, 'Room is full');
  try { const r = db.prepare("INSERT INTO booking(user_id,room_id,desk_preference,status) VALUES(?,?,?,'pending')").run(user.sub, room_id, desk); return [201, { booking_id: Number(r.lastInsertRowid), status: 'pending' }]; }
  catch (e) { if (uniqueHit(e)) throw new HttpError(409, 'You already have an open booking'); throw e; }
});
route('PATCH', '/api/bookings/:id', 'admin', ({ params, body }) => {
  const id = int(+params.id, 'id', 1, 1e9), status = oneOf(body.status, 'status', ['pending', 'approved', 'rejected']);
  db.exec('BEGIN IMMEDIATE');
  try {
    const b = db.prepare('SELECT b.*, r.capacity FROM booking b JOIN room r USING(room_id) WHERE booking_id=?').get(id);
    if (!b) throw new HttpError(404, 'Booking not found');
    if (status === 'approved') {
      const n = db.prepare("SELECT COUNT(*) c FROM booking WHERE room_id=? AND status='approved' AND booking_id<>?").get(b.room_id, id).c;
      if (n >= b.capacity) throw new HttpError(409, 'No free bed left in this room');
    }
    db.prepare('UPDATE booking SET status=? WHERE booking_id=?').run(status, id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); if (uniqueHit(e)) throw new HttpError(409, 'Student already has another open booking'); throw e; }
  emit('room', {}); return [200, { ok: true, status }];
});
route('DELETE', '/api/bookings/:id', 'any', ({ user, params }) => {
  const id = int(+params.id, 'id', 1, 1e9), b = db.prepare('SELECT * FROM booking WHERE booking_id=?').get(id);
  if (!b) throw new HttpError(404, 'Booking not found');
  if (user.role !== 'admin' && (b.user_id !== user.sub || b.status !== 'pending')) throw new HttpError(403, 'You can only cancel your own pending booking');
  db.prepare('DELETE FROM booking WHERE booking_id=?').run(id); emit('room', {}); return [200, { ok: true }];
});

// TELEMETRY, ALERTS, ACCESS (admin) + device ingest
route('GET', '/api/telemetry', 'admin', ({ query }) => {
  const id = int(+query.get('room_id'), 'room_id', 1, 1e9), lim = int(+(query.get('limit') || 40), 'limit', 1, 500);
  const q = db.prepare('SELECT metric_value v, logged_at t FROM (SELECT * FROM telemetry_event WHERE room_id=? AND sensor_type=? ORDER BY logged_at DESC, event_id DESC LIMIT ?) ORDER BY t');
  return [200, { occupancy: q.all(id, 'occupancy', lim), temperature: q.all(id, 'temperature', lim) }];
});
route('POST', '/api/telemetry', 'device', ({ body }) => {
  const e = { room_id: int(body.room_id, 'room_id', 1, 1e9), sensor_type: oneOf(body.sensor_type, 'sensor_type', ['occupancy', 'temperature']),
    metric_value: Number(body.metric_value), logged_at: body.logged_at ? new Date(body.logged_at).toISOString() : new Date().toISOString() };
  if (!Number.isFinite(e.metric_value) || e.metric_value < 0 || e.metric_value > 100) throw bad('metric_value must be a number 0-100');
  if (!db.prepare('SELECT 1 FROM room WHERE room_id=?').get(e.room_id)) throw new HttpError(404, 'Room not found');
  ingestTelemetry(db, e, emit); return [201, { ok: true }];
});
route('POST', '/api/scan', 'admin', ({ body }) => {
  const id = int(body.room_id, 'room_id', 1, 1e9), outcome = oneOf(body.outcome, 'outcome', ['granted', 'denied']);
  if (!db.prepare('SELECT 1 FROM room WHERE room_id=?').get(id)) throw new HttpError(404, 'Room not found');
  recordScan(db, id, outcome, emit); return [201, { room: roomRows().find((r) => r.room_id === id) }];
});
route('POST', '/api/demo/empty-room', 'admin', ({ body }) => { const id = int(body.room_id, 'room_id', 1, 1e9); control.forceEmpty.set(id, 12); return [202, { ok: true }]; });
route('POST', '/api/demo/reset', 'admin', () => {
  db.exec("DELETE FROM booking; DELETE FROM alert; DELETE FROM access_event; UPDATE room SET hvac_mode='NORMAL', reader_locked=0");
  emit('room', {}); return [200, { ok: true }];
});
route('GET', '/api/alerts', 'admin', () => [200, db.prepare('SELECT a.*, r.room_number FROM alert a JOIN room r USING(room_id) ORDER BY alert_id DESC LIMIT 50').all()]);
route('GET', '/api/summary', 'admin', () => {
  const ev = db.prepare("SELECT COUNT(*) total, SUM(outcome='denied') denied FROM access_event").get();
  return [200, { access_denial_pct: ev.total ? Math.round((1000 * ev.denied) / ev.total) / 10 : 0, scans: ev.total,
    eco_rooms: db.prepare("SELECT COUNT(*) c FROM room WHERE hvac_mode='ECO'").get().c, locked_readers: db.prepare('SELECT COUNT(*) c FROM room WHERE reader_locked=1').get().c,
    pending_bookings: db.prepare("SELECT COUNT(*) c FROM booking WHERE status='pending'").get().c }];
});

// ---------- HTTP plumbing ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
const SEC = { 'Content-Security-Policy': "default-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'", 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store' };
const send = (res, status, data) => { res.writeHead(status, { ...SEC, 'Content-Type': 'application/json' }); res.end(JSON.stringify(data)); };
const readBody = (req) => new Promise((ok, no) => { let s = ''; req.on('data', (c) => { s += c; if (s.length > 10000) { no(new HttpError(413, 'Body too large')); req.destroy(); } }); req.on('end', () => { try { ok(s ? JSON.parse(s) : {}); } catch { no(bad('Invalid JSON')); } }); });

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const ip = (TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress;
    if (req.headers['x-forwarded-proto'] === 'https') res.setHeader('Strict-Transport-Security', 'max-age=15552000');
    if (url.pathname === '/healthz') return send(res, 200, { ok: true });
    if (url.pathname === '/api/stream') { // live updates (Server-Sent Events), admin only
      const u = verifyToken(url.searchParams.get('token'));
      if (!u || u.role !== 'admin') return send(res, u ? 403 : 401, { error: u ? 'Admin role required' : 'Sign in required' });
      res.writeHead(200, { ...SEC, 'Content-Type': 'text/event-stream', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' }); res.write(': connected\n\n');
      clients.add(res); req.on('close', () => clients.delete(res)); return;
    }
    if (url.pathname.startsWith('/api/')) {
      const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
      if (!r) return send(res, 404, { error: 'Not found' });
      let user = null;
      if (r.auth === 'device') { if (req.headers['x-device-key'] !== DEVICE_KEY) return send(res, 401, { error: 'Invalid device key' }); }
      else if (r.auth) {
        user = verifyToken((req.headers.authorization || '').replace(/^Bearer /, ''));
        if (!user) return send(res, 401, { error: 'Sign in required' });
        if (r.auth !== 'any' && user.role !== r.auth) return send(res, 403, { error: `Forbidden: ${r.auth} role required` });
      }
      const body = ['POST', 'PATCH', 'PUT'].includes(req.method) ? await readBody(req) : {};
      const [status, data] = r.fn({ user, body, ip, params: url.pathname.match(r.re).groups || {}, query: url.searchParams });
      return send(res, status, data);
    }
    let p = normalize(join(PUBLIC, url.pathname === '/' ? 'index.html' : url.pathname));
    if (!p.startsWith(PUBLIC.replace(/[\\/]$/, '') + sep)) return send(res, 403, { error: 'Forbidden' });
    const file = await readFile(p).catch(() => null);
    if (!file) return send(res, 404, { error: 'Not found' });
    res.writeHead(200, { ...SEC, 'Content-Type': MIME[extname(p)] || 'application/octet-stream' }); res.end(file);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    console.error(e); send(res, 500, { error: 'Server error' });
  }
});
setInterval(() => { for (const c of clients) c.write(': ping\n\n'); }, 25000).unref(); // keeps live connections open through proxies
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => { server.close(); db.close(); process.exit(0); });
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\nPort ${PORT} is already in use. Close the other program (or an old copy of this app), or use another port, e.g. in cmd:  set PORT=3001 && node server.js`);
  else console.error(e);
  process.exit(1);
});
server.listen(...(HOST ? [PORT, HOST] : [PORT]), () => {
  console.log(`LCMA prototype running at http://localhost:${PORT}`);
  if (process.env.LCMA_SIM !== '0') startSimulator(db, emit);
});
