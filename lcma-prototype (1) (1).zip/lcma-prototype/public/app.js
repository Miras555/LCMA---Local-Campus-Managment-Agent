// LCMA prototype front end (vanilla JS, no build step). All user data is escaped before it reaches the page.
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let token = sessionStorage.getItem('lcma_token'), me = null, rooms = [], tab = 'dashboard', es = null;
const series = {}; // room_id -> {occupancy:[], temperature:[]}

async function api(path, { method = 'GET', body } = {}) {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || r.statusText), { status: r.status });
  return d;
}
function toast(msg, err) { const t = $('#toast'); t.textContent = msg; t.className = 'toast' + (err ? ' err' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add('hidden'), 3200); }
const run = async (fn) => { try { await fn(); } catch (e) { if (e.status === 401 && me) return logout(); toast(e.message, true); } };
const pill = (v, cls) => `<span class="pill ${esc(cls || v)}">${esc(v)}</span>`;
const time = (t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

// ---------- sign-in ----------
async function loginView() {
  $('#who').classList.add('hidden');
  let hint = 'all'; try { hint = (await api('/config')).demo_hint; } catch {}
  const demo = hint === 'none' ? '' : `<p class="muted">Prototype demo accounts (fictional data):</p><p class="muted">${hint === 'all' ? '<b>Admin</b> admin@lcma.kz / Admin#2026demo<br>' : ''}<b>Student</b> student1@lcma.kz / Student#2026demo</p>`;
  $('#app').innerHTML = `<div class="card login"><h1>Sign in</h1>${demo}
  <label for="em">Email</label><input id="em" autocomplete="username" inputmode="email"><label for="pw">Password</label><input id="pw" type="password" autocomplete="current-password">
  <p><button id="go">Sign in</button></p><div id="lerr" class="err"></div></div>`;
  const go = () => run(async () => {
    $('#lerr').textContent = '';
    try { const d = await api('/login', { method: 'POST', body: { email: $('#em').value, password: $('#pw').value } }); token = d.token; sessionStorage.setItem('lcma_token', token); await boot(); }
    catch (e) { $('#lerr').textContent = e.message; }
  });
  $('#go').onclick = go; $('#pw').onkeydown = (e) => e.key === 'Enter' && go();
}
function logout() { token = null; me = null; sessionStorage.removeItem('lcma_token'); if (es) es.close(); loginView(); }
async function boot() {
  try { me = await api('/me'); } catch { return loginView(); }
  $('#who').classList.remove('hidden');
  $('#who').innerHTML = `<span>${esc(me.display_name)}</span>${pill(me.role, me.role === 'admin' ? 'approved' : 'pending')}<button class="alt sm" data-act="logout">Sign out</button>`;
  me.role === 'admin' ? adminView() : studentView();
}

// ---------- student ----------
async function studentView() {
  rooms = await api('/rooms'); const mine = await api('/bookings');
  const open = mine.find((b) => b.status !== 'rejected');
  $('#app').innerHTML = `<div class="card"><h2>My booking</h2>${mine.length ? mine.map((b) => `<div class="rm"><div><b>${esc(b.room_number)}</b> · ${esc(b.hall)}<br><span class="muted">Desk: ${esc(b.desk_preference)}</span></div><div class="rma">${pill(b.status)}${b.status === 'pending' ? `<button class="alt sm" data-act="cancel" data-id="${b.booking_id}">Cancel</button>` : ''}</div></div>`).join('') : '<p class="muted">No booking yet. Pick a room below.</p>'}</div>
  <div class="card"><h2>Available rooms</h2>${rooms.map((r) => `<div class="rm"><div><b>${esc(r.room_number)}</b> · ${esc(r.hall)}<br><span class="muted">${r.price_kzt.toLocaleString()} KZT / month · ${r.free_beds} of ${r.capacity} beds free</span></div>
  <div class="rma"><select id="d${r.room_id}" aria-label="Desk preference for ${esc(r.room_number)}"><option>window</option><option>wall</option></select><button class="sm" data-act="apply" data-id="${r.room_id}" ${r.free_beds < 1 || open ? 'disabled' : ''}>Apply</button></div></div>`).join('')}
  <p class="muted">Staff approve applications. Capacity is checked again at approval.</p></div>
  <div class="card"><h2>Security test (for the demo)</h2><p class="muted">A student token must not reach admin data. The server decides, not the screen.</p>
  <button class="dark" data-act="sectest">Call admin endpoint /api/alerts</button><pre id="sec" class="hidden"></pre></div>`;
}

// ---------- admin ----------
async function adminView() {
  $('#app').innerHTML = `<div class="tabs">${['dashboard', 'bookings', 'rooms', 'alerts', 'security'].map((t) => `<button data-act="tab" data-t="${t}" class="${t === tab ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div><div id="pane"></div>`;
  await refreshPane(); connectStream();
}
async function refreshPane() { if (me?.role !== 'admin') return; const p = { dashboard, bookings, rooms: roomsTab, alerts, security }[tab]; await p(); }
async function dashboard() {
  const [sum, rs] = await Promise.all([api('/summary'), api('/rooms')]); rooms = rs;
  for (const r of rs) if (!series[r.room_id]) series[r.room_id] = await api('/telemetry?room_id=' + r.room_id + '&limit=40');
  $('#pane').innerHTML = `<div class="kpis"><div class="kpi"><span>Access denial rate</span><b>${sum.access_denial_pct}%</b><span>${sum.scans} scans</span></div><div class="kpi"><span>Rooms in ECO mode</span><b>${sum.eco_rooms}</b><span>HVAC rule 1</span></div>
  <div class="kpi"><span>Locked readers</span><b>${sum.locked_readers}</b><span>Access rule 2</span></div><div class="kpi"><span>Pending bookings</span><b>${sum.pending_bookings}</b><span>need a decision</span></div></div>
  <p class="live">● LIVE · simulated sensors, 1 tick = 5 min</p><div class="rooms">${rs.map((r) => `<div class="card room"><h3><span>${esc(r.room_number)} · ${esc(r.hall)}</span><span>${pill('HVAC ' + r.hvac_mode, r.hvac_mode)} ${r.reader_locked ? pill('READER LOCKED', 'locked') : ''}</span></h3>
  <div class="stats" id="st${r.room_id}"></div><canvas id="cv${r.room_id}" width="520" height="150"></canvas><div class="legend"><i class="lo"></i>Occupancy<i class="lt"></i>Temperature °C</div></div>`).join('')}</div>`;
  rs.forEach((r) => draw(r.room_id));
}
function draw(id) {
  const s = series[id], cv = $('#cv' + id); if (!s || !cv) return;
  const room = rooms.find((r) => r.room_id === id), cap = room ? room.capacity : 4, g = cv.getContext('2d'), W = cv.width, H = cv.height;
  g.clearRect(0, 0, W, H); g.strokeStyle = '#e2e8f0'; g.fillStyle = '#64748b'; g.font = '11px sans-serif';
  for (let i = 0; i <= 4; i++) { const y = 10 + (i * (H - 24)) / 4; g.beginPath(); g.moveTo(34, y); g.lineTo(W - 6, y); g.stroke(); g.fillText(Math.round((cap * (4 - i)) / 4 * 10) / 10, 4, y + 4); }
  const line = (pts, lo, hi, col) => { if (!pts.length) return; g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); pts.forEach((p, i) => { const x = 34 + (i * (W - 40)) / Math.max(pts.length - 1, 1), y = 10 + (H - 24) * (1 - (p.v - lo) / (hi - lo)); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke(); };
  line(s.occupancy, 0, cap, '#0ea5e9'); line(s.temperature, 15, 25, '#e11d48');
  const o = s.occupancy.at(-1), t = s.temperature.at(-1);
  $('#st' + id).innerHTML = `<span>Occupancy <b>${o ? o.v : '–'}</b> / ${cap}</span><span>Temp <b>${t ? t.v.toFixed(1) : '–'} °C</b></span><span>Last reading <b>${o ? time(o.t) : '–'}</b></span>`;
}
async function bookings() {
  const bs = await api('/bookings');
  $('#pane').innerHTML = `<div class="card"><h2>Housing applications</h2><table><tr><th>Student</th><th>Room</th><th>Desk</th><th>Status</th><th>Actions</th></tr>${bs.map((b) => `<tr><td>${esc(b.display_name)}<br><span class="muted">${esc(b.email)}</span></td><td>${esc(b.room_number)} · ${esc(b.hall)}</td><td>${esc(b.desk_preference)}</td><td>${pill(b.status)}</td>
  <td><button class="sm" data-act="decide" data-id="${b.booking_id}" data-s="approved">Approve</button> <button class="alt sm" data-act="decide" data-id="${b.booking_id}" data-s="rejected">Reject</button> <button class="red sm" data-act="delbooking" data-id="${b.booking_id}">Delete</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No applications yet.</td></tr>'}</table></div>`;
}
async function roomsTab() {
  rooms = await api('/rooms');
  $('#pane').innerHTML = `<div class="card"><h2>Add a room</h2><div class="form"><div><label for="nr">Room no.</label><input id="nr" placeholder="N-206"></div><div><label for="nh">Hall</label><input id="nh" placeholder="North Hall"></div>
  <div><label for="nc">Beds (1-6)</label><input id="nc" type="number" min="1" max="6" value="2"></div><div><label for="np">Price KZT</label><input id="np" type="number" value="45000"></div><button data-act="addroom">Create</button></div></div>
  <div class="card"><h2>Room inventory</h2><table><tr><th>Room</th><th>Hall</th><th>Beds</th><th>Free</th><th>Price</th><th></th></tr>${rooms.map((r) => `<tr><td><b>${esc(r.room_number)}</b></td><td>${esc(r.hall)}</td><td>${r.capacity}</td><td>${r.free_beds}</td><td>${r.price_kzt.toLocaleString()}</td>
  <td><button class="alt sm" data-act="editprice" data-id="${r.room_id}" data-p="${r.price_kzt}">Edit price</button> <button class="red sm" data-act="delroom" data-id="${r.room_id}">Delete</button></td></tr>`).join('')}</table></div>`;
}
async function alerts() {
  const a = await api('/alerts');
  $('#pane').innerHTML = `<div class="card"><h2>Rule alerts</h2>${a.map((x) => `<div class="alert">${pill(x.kind)}<span>${esc(x.message)}</span><span class="muted">${esc(new Date(x.created_at).toLocaleTimeString())}</span></div>`).join('') || '<p class="muted">No alerts yet. Wait for an empty room or simulate denied scans.</p>'}</div>`;
}
async function security() {
  rooms = await api('/rooms');
  const opts = rooms.map((r) => `<option value="${r.room_id}">${esc(r.room_number)}${r.reader_locked ? ' (locked)' : ''}</option>`).join('');
  $('#pane').innerHTML = `<div class="card"><h2>Simulated door reader (rule 2)</h2><p class="muted">More than 3 denied scans in 5 minutes locks the reader and raises an alert.</p><div class="row"><div><label for="sr">Room</label><select id="sr">${opts}</select></div>
  <button data-act="scan" data-o="granted">Valid card</button><button class="red" data-act="scan" data-o="denied">Denied card</button><button class="alt" data-act="unlock">Unlock reader</button></div><pre id="scanout" class="hidden"></pre></div>
  <div class="card"><h2>Empty-room demo (rule 1)</h2><p class="muted">Forces the sensor to report 0 people for ~1 minute of real time (60 simulated minutes). Watch HVAC switch to ECO on the dashboard.</p><div class="row"><div><label for="er">Room</label><select id="er">${opts}</select></div><button data-act="empty">Simulate empty room</button></div></div>
  <div class="card"><h2>Reset demo data</h2><p class="muted">Deletes all bookings, alerts and scan history, and resets HVAC and readers. Rooms and users stay.</p><button class="red" data-act="reset">Reset demo data</button></div>
  <div class="card"><h2>Input validation test</h2><p class="muted">Sends a SQL injection string as the email. The server must refuse it.</p><button class="dark" data-act="inject">Send ' OR 1=1 --</button><pre id="injout" class="hidden"></pre></div>`;
}

// ---------- live stream (Server-Sent Events) ----------
function connectStream() {
  if (es) es.close(); es = new EventSource('/api/stream?token=' + encodeURIComponent(token));
  es.addEventListener('telemetry', (e) => {
    const d = JSON.parse(e.data), s = series[d.room_id]; if (!s) return;
    const arr = s[d.sensor_type]; arr.push({ v: d.metric_value, t: d.logged_at }); if (arr.length > 40) arr.shift();
    if (tab === 'dashboard') draw(d.room_id);
  });
  for (const t of ['room', 'alert', 'scan']) es.addEventListener(t, (ev) => { if (['dashboard', 'alerts'].includes(tab)) run(refreshPane); if (t === 'alert') toast(JSON.parse(ev.data).message); });
}

// ---------- actions ----------
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return; const d = b.dataset;
  run(async () => {
    switch (d.act) {
      case 'logout': return logout();
      case 'tab': tab = d.t; return adminView();
      case 'apply': await api('/bookings', { method: 'POST', body: { room_id: +d.id, desk_preference: $('#d' + d.id).value } }); toast('Application sent (pending)'); return studentView();
      case 'cancel': await api('/bookings/' + d.id, { method: 'DELETE' }); toast('Booking cancelled'); return studentView();
      case 'sectest': { const out = $('#sec'); out.classList.remove('hidden'); try { await api('/alerts'); out.textContent = 'Unexpected: access granted'; } catch (x) { out.textContent = `HTTP ${x.status}\n${x.message}`; } return; }
      case 'decide': await api('/bookings/' + d.id, { method: 'PATCH', body: { status: d.s } }); toast('Booking ' + d.s); return bookings();
      case 'delbooking': await api('/bookings/' + d.id, { method: 'DELETE' }); toast('Booking deleted'); return bookings();
      case 'addroom': await api('/rooms', { method: 'POST', body: { room_number: $('#nr').value, hall: $('#nh').value, capacity: +$('#nc').value, price_kzt: +$('#np').value } }); toast('Room created'); return roomsTab();
      case 'editprice': { const v = prompt('New monthly price in KZT', d.p); if (v === null) return; await api('/rooms/' + d.id, { method: 'PATCH', body: { price_kzt: Math.trunc(+v) } }); toast('Price updated'); return roomsTab(); }
      case 'delroom': if (!confirm('Delete this room and its data?')) return; await api('/rooms/' + d.id, { method: 'DELETE' }); delete series[d.id]; toast('Room deleted'); return roomsTab();
      case 'scan': { const r = await api('/scan', { method: 'POST', body: { room_id: +$('#sr').value, outcome: d.o } }); const o = $('#scanout'); o.classList.remove('hidden'); o.textContent = `Scan ${d.o}. Reader ${r.room.reader_locked ? 'LOCKED' : 'active'} for ${r.room.room_number}.`; return; }
      case 'unlock': await api('/rooms/' + $('#sr').value, { method: 'PATCH', body: { reader_locked: 0 } }); toast('Reader unlocked'); return security();
      case 'empty': await api('/demo/empty-room', { method: 'POST', body: { room_id: +$('#er').value } }); return toast('Room reports empty. Open Dashboard to watch the rule.');
      case 'reset': if (!confirm('Reset bookings, alerts and scan history?')) return; await api('/demo/reset', { method: 'POST' }); toast('Demo data reset'); return security();
      case 'inject': { const o = $('#injout'); o.classList.remove('hidden'); try { await api('/login', { method: 'POST', body: { email: "' OR 1=1 --", password: 'x' } }); o.textContent = 'Unexpected: accepted'; } catch (x) { o.textContent = `HTTP ${x.status}\n${x.message}`; } return; }
    }
  });
});
token ? boot() : loginView();
