// Self-check: node tools/doctor.mjs   (or double-click start.bat). Tells you exactly what is wrong on this computer.
import { existsSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import net from 'node:net';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
let bad = 0;
const say = (ok, msg, fix) => { if (!ok) bad++; console.log(`${ok ? 'OK    ' : 'PROBLEM'}  ${msg}${!ok && fix ? '\n         -> ' + fix : ''}`); };
const [maj, min] = process.versions.node.split('.').map(Number);
say(maj > 22 || (maj === 22 && min >= 13), `Node.js version ${process.versions.node} (need 22.13 or newer)`, 'Install the latest LTS from https://nodejs.org, then open a NEW terminal.');
for (const f of ['server.js', 'schema.sql', 'package.json', 'lib/auth.js', 'lib/db.js', 'lib/rules.js', 'lib/sim.js', 'public/index.html', 'public/app.js', 'public/styles.css'])
  say(existsSync(join(root, f)), `File ${f}`, 'The zip was not fully extracted. Extract ALL files (right-click > Extract All) and run again.');
say(!/onedrive/i.test(root), 'Project folder is not inside OneDrive', 'Copy the folder to a normal place such as C:\\lcma-prototype (OneDrive can lock or sync database files).');
try {
  const { DatabaseSync } = await import('node:sqlite');
  const p = join(root, 'doctor-test.db'); const db = new DatabaseSync(p);
  db.exec('CREATE TABLE t(x INTEGER); INSERT INTO t VALUES (1);'); db.close(); rmSync(p, { force: true });
  say(true, 'SQLite database can be created and written in this folder');
} catch (e) { say(false, `SQLite check failed: ${e.message}`, 'Move the folder to C:\\lcma-prototype, or set DB_PATH to a writable folder.'); }
const port = +process.env.PORT || 3000;
await new Promise((done) => { const s = net.createServer().once('error', (e) => { say(false, `Port ${port} is free`, e.code === 'EADDRINUSE' ? `Another program uses port ${port}. Close it, or use: set PORT=3001 && node server.js` : e.message); done(); }).once('listening', () => { s.close(); say(true, `Port ${port} is free`); done(); }).listen(port); });
console.log(bad ? `\n${bad} problem(s) found. Fix them and run again.` : `\nAll good. Start the app with:  node server.js   then open http://localhost:${port}`);
process.exit(bad ? 1 : 0);
