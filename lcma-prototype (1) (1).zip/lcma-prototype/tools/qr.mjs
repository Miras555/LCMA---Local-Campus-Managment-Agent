// Dependency-free QR code generator (byte mode, error correction M, versions 1-10 => up to ~213 characters).
// Usage: node tools/qr.mjs https://your-app.example.com [output-name]   -> writes <name>.svg and <name>.png
import { writeFileSync } from 'node:fs';
import { deflateSync } from 'node:zlib';

// [ecCodewordsPerBlock, blocks1, dataPerBlock1, blocks2, dataPerBlock2] for level M
const BLOCKS = [null, [10,1,16,0,0],[16,1,28,0,0],[26,1,44,0,0],[18,2,32,0,0],[24,2,43,0,0],[16,4,27,0,0],[18,4,31,0,0],[22,2,38,2,39],[22,3,36,2,37],[26,4,43,1,44]];
const ALIGN = [null, [], [6,18], [6,22], [6,26], [6,30], [6,34], [6,22,38], [6,24,42], [6,26,46], [6,28,50]];

// Reed-Solomon over GF(256), polynomial 0x11D
const EXP = new Array(512), LOG = new Array(256);
for (let i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; }
for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
const gmul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
function rsCodewords(data, ecLen) {
  let gen = [1];
  for (let i = 0; i < ecLen; i++) { const next = new Array(gen.length + 1).fill(0); gen.forEach((c, j) => { next[j] ^= c; next[j + 1] ^= gmul(c, EXP[i]); }); gen = next; }
  const res = new Array(ecLen).fill(0);
  for (const b of data) { const f = b ^ res[0]; res.shift(); res.push(0); if (f) gen.slice(1).forEach((c, j) => { res[j] ^= gmul(c, f); }); }
  return res;
}
const bch = (v, poly, deg) => { let r = v << deg; for (let i = 31; i >= deg; i--) if ((r >> i) & 1) r ^= poly << (i - deg); return r; };

export function makeQr(text) {
  const bytes = [...Buffer.from(text, 'utf8')];
  let ver = 0;
  for (let v = 1; v <= 10; v++) { const [ec, b1, d1, b2, d2] = BLOCKS[v]; const cap = b1 * d1 + b2 * d2; if (bytes.length + (v < 10 ? 2 : 3) <= cap) { ver = v; break; } }
  if (!ver) throw new Error('Text too long for this generator (max ~213 characters). Use a shorter URL.');
  const [ecLen, b1, d1, b2, d2] = BLOCKS[ver], totalData = b1 * d1 + b2 * d2;
  // bit stream
  const bits = []; const put = (v, n) => { for (let i = n - 1; i >= 0; i--) bits.push((v >> i) & 1); };
  put(4, 4); put(bytes.length, ver < 10 ? 8 : 16); bytes.forEach((b) => put(b, 8));
  put(0, Math.min(4, totalData * 8 - bits.length)); while (bits.length % 8) bits.push(0);
  const data = []; for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let pad = 0xec; data.length < totalData; pad ^= 0xec ^ 0x11) data.push(pad);
  // blocks + interleave
  const blocks = []; let pos = 0;
  for (let i = 0; i < b1 + b2; i++) { const n = i < b1 ? d1 : d2; const d = data.slice(pos, pos + n); pos += n; blocks.push({ d, e: rsCodewords(d, ecLen) }); }
  const out = [];
  for (let i = 0; i < Math.max(d1, d2); i++) blocks.forEach((b) => { if (i < b.d.length) out.push(b.d[i]); });
  for (let i = 0; i < ecLen; i++) blocks.forEach((b) => out.push(b.e[i]));
  const stream = []; out.forEach((b) => put2(stream, b));
  function put2(arr, b) { for (let i = 7; i >= 0; i--) arr.push((b >> i) & 1); }
  // matrix
  const N = ver * 4 + 17, M = Array.from({ length: N }, () => new Array(N).fill(0)), F = Array.from({ length: N }, () => new Array(N).fill(false));
  const set = (r, c, v) => { if (r >= 0 && c >= 0 && r < N && c < N) { M[r][c] = v ? 1 : 0; F[r][c] = true; } };
  const finder = (r0, c0) => { for (let r = -1; r <= 7; r++) for (let c = -1; c <= 7; c++) { const d = Math.max(Math.abs(r - 3), Math.abs(c - 3)); set(r0 + r, c0 + c, r >= 0 && r <= 6 && c >= 0 && c <= 6 && d !== 2); } };
  finder(0, 0); finder(0, N - 7); finder(N - 7, 0);
  for (let i = 8; i < N - 8; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
  const ap = ALIGN[ver];
  for (const r of ap) for (const c of ap) { if ((r === 6 && c === 6) || (r === 6 && c === ap.at(-1)) || (r === ap.at(-1) && c === 6)) continue; for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) set(r + dr, c + dc, Math.max(Math.abs(dr), Math.abs(dc)) !== 1); }
  set(N - 8, 8, true); // dark module
  for (let i = 0; i < 9; i++) { if (!F[8][i]) set(8, i, 0); if (!F[i][8]) set(i, 8, 0); }
  for (let i = 0; i < 8; i++) { set(8, N - 1 - i, 0); set(N - 1 - i, 8, 0); }
  if (ver >= 7) { const vi = (ver << 12) | bch(ver, 0x1f25, 12); for (let i = 0; i < 18; i++) { const bit = (vi >> i) & 1, a = Math.floor(i / 3), b = (i % 3) + N - 11; set(a, b, bit); set(b, a, bit); } }
  // place data (zigzag)
  const place = (mask) => {
    const G = M.map((r) => r.slice()); let k = 0;
    let up = true;
    for (let c = N - 1; c > 0; c -= 2) {
      if (c === 6) c = 5;
      for (let t = 0; t < N; t++) { const r = up ? N - 1 - t : t; for (let j = 0; j < 2; j++) { const col = c - j; if (F[r][col]) continue; let bit = k < stream.length ? stream[k] : 0; k++; if (maskFn(mask, r, col)) bit ^= 1; G[r][col] = bit; } }
      up = !up;
    }
    return G;
  };
  const maskFn = (m, r, c) => [(r + c) % 2 === 0, r % 2 === 0, c % 3 === 0, (r + c) % 3 === 0, (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0, ((r * c) % 2) + ((r * c) % 3) === 0, (((r * c) % 2) + ((r * c) % 3)) % 2 === 0, (((r + c) % 2) + ((r * c) % 3)) % 2 === 0][m];
  const penalty = (G) => {
    let p = 0;
    for (let pass = 0; pass < 2; pass++) for (let a = 0; a < N; a++) { let run = 1; for (let b = 1; b < N; b++) { const cur = pass ? G[b][a] : G[a][b], prev = pass ? G[b - 1][a] : G[a][b - 1]; if (cur === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
    for (let r = 0; r < N - 1; r++) for (let c = 0; c < N - 1; c++) if (G[r][c] === G[r][c + 1] && G[r][c] === G[r + 1][c] && G[r][c] === G[r + 1][c + 1]) p += 3;
    const pat = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], rev = [...pat].reverse();
    for (let pass = 0; pass < 2; pass++) for (let a = 0; a < N; a++) for (let b = 0; b <= N - 11; b++) { const line = []; for (let k = 0; k < 11; k++) line.push(pass ? G[b + k][a] : G[a][b + k]); if (line.every((v, i) => v === pat[i]) || line.every((v, i) => v === rev[i])) p += 40; }
    const dark = G.flat().filter(Boolean).length; p += Math.floor(Math.abs((dark * 100) / (N * N) - 50) / 5) * 10;
    return p;
  };
  let best = null, bestP = Infinity;
  for (let m = 0; m < 8; m++) {
    const G = place(m); const fmt = (((0 << 3) | m) << 10 | bch((0 << 3) | m, 0x537, 10)) ^ 0x5412; // level M = 00
    const sf = (r, c, i) => { G[r][c] = (fmt >> i) & 1; };
    for (let i = 0; i <= 5; i++) sf(i, 8, i); sf(7, 8, 6); sf(8, 8, 7); sf(8, 7, 8); for (let i = 9; i < 15; i++) sf(8, 14 - i, i);
    for (let i = 0; i < 8; i++) sf(8, N - 1 - i, i); for (let i = 8; i < 15; i++) sf(N - 15 + i, 8, i);
    G[N - 8][8] = 1;
    const p = penalty(G); if (p < bestP) { bestP = p; best = G; }
  }
  return best;
}

export function toSvg(G, scale = 10, quiet = 4) {
  const n = G.length, size = (n + quiet * 2) * scale; let d = '';
  G.forEach((row, r) => row.forEach((v, c) => { if (v) d += `M${(c + quiet) * scale} ${(r + quiet) * scale}h${scale}v${scale}h-${scale}z`; }));
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>\n`;
}
const crcT = new Uint32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
const crc = (buf) => { let c = 0xffffffff; for (const b of buf) c = crcT[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
export function toPng(G, scale = 12, quiet = 4) {
  const n = G.length, W = (n + quiet * 2) * scale, raw = Buffer.alloc((W + 1) * W, 255);
  for (let y = 0; y < W; y++) { raw[y * (W + 1)] = 0; for (let x = 0; x < W; x++) { const r = Math.floor(y / scale) - quiet, c = Math.floor(x / scale) - quiet; if (r >= 0 && c >= 0 && r < n && c < n && G[r][c]) raw[y * (W + 1) + 1 + x] = 0; } }
  const chunk = (t, d) => { const b = Buffer.alloc(12 + d.length); b.writeUInt32BE(d.length, 0); b.write(t, 4); d.copy(b, 8); b.writeUInt32BE(crc(b.subarray(4, 8 + d.length)), 8 + d.length); return b; };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(W, 4); ihdr[8] = 8; ihdr[9] = 0;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
if (process.argv[1] && process.argv[1].endsWith('qr.mjs')) {
  const [, , url, name = 'lcma-qr'] = process.argv;
  if (!url) { console.log('Usage: node tools/qr.mjs https://your-app.example.com [output-name]'); process.exit(1); }
  const G = makeQr(url); writeFileSync(name + '.svg', toSvg(G)); writeFileSync(name + '.png', toPng(G));
  console.log(`Wrote ${name}.svg and ${name}.png for ${url}`);
}
