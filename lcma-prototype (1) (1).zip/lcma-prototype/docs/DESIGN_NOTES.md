# Design notes: prototype vs earlier slides

Update the design document and slides so every diagram matches this build.

## Tables built (6)
`app_user`, `room` (+ `hvac_mode`, `reader_locked`), `booking`, `telemetry_event`, `access_event`, `alert`. See `schema.sql`.
Relationships: booking N:1 app_user, booking N:1 room, telemetry_event N:1 room, access_event N:1 room, alert N:1 room.
Rules in SQL: UNIQUE email, CHECK on role/status/capacity/price, one open booking per student (partial unique index), cascading deletes.

## Differences from the end-term slides (change them or be ready to explain)
| Slides said | Prototype uses | Why |
|---|---|---|
| PostgreSQL | SQLite (`node:sqlite`) | Runs with zero installation. `schema.sql` uses standard types; for PostgreSQL swap `INTEGER PRIMARY KEY AUTOINCREMENT` for `SERIAL`, `datetime('now')` for `now()`, and the driver. |
| Node/Express | Node `http` module with a small router | No dependencies to install. Routes and middleware logic are the same shape. |
| bcrypt | scrypt (Node crypto) | Same purpose (slow salted hash), built in. |
| JWT middleware | HS256 JWT written with `node:crypto` | Same token format. |
| WebSockets | Server-Sent Events | One-way live updates are enough for the dashboard. |
| React SPA | Vanilla JavaScript SPA | No build step. |
| MQTT broker | Simulator calls the ingest code directly; `POST /api/telemetry` accepts real devices with the `x-device-key` header | No broker available in the demo environment. |
