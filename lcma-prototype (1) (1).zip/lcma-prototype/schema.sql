-- LCMA prototype schema (SQLite dialect; types map 1:1 to PostgreSQL, see README)
CREATE TABLE IF NOT EXISTS app_user(
  user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE CHECK(length(email) BETWEEN 5 AND 120),
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('student','admin')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS room(
  room_id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_number TEXT NOT NULL UNIQUE,
  hall TEXT NOT NULL,
  capacity INTEGER NOT NULL CHECK(capacity BETWEEN 1 AND 6),
  price_kzt INTEGER NOT NULL CHECK(price_kzt >= 0),
  hvac_mode TEXT NOT NULL DEFAULT 'NORMAL' CHECK(hvac_mode IN ('NORMAL','ECO')),
  reader_locked INTEGER NOT NULL DEFAULT 0 CHECK(reader_locked IN (0,1)));
CREATE TABLE IF NOT EXISTS booking(
  booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES room(room_id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  desk_preference TEXT NOT NULL DEFAULT 'window' CHECK(desk_preference IN ('window','wall')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE UNIQUE INDEX IF NOT EXISTS one_open_booking ON booking(user_id) WHERE status IN ('pending','approved');
CREATE TABLE IF NOT EXISTS telemetry_event(
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES room(room_id) ON DELETE CASCADE,
  sensor_type TEXT NOT NULL CHECK(sensor_type IN ('occupancy','temperature')),
  metric_value REAL NOT NULL,
  logged_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS telemetry_lookup ON telemetry_event(room_id, sensor_type, logged_at);
CREATE TABLE IF NOT EXISTS access_event(
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES room(room_id) ON DELETE CASCADE,
  outcome TEXT NOT NULL CHECK(outcome IN ('granted','denied')),
  logged_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS alert(
  alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES room(room_id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('hvac','security')),
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')));
