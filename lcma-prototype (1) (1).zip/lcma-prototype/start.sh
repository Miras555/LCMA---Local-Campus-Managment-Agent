#!/bin/sh
cd "$(dirname "$0")" && node tools/doctor.mjs && node server.js
