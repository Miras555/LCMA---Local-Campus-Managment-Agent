# Put the prototype online and open it from a QR code

Goal: a public **https://** link that anyone can open on a phone, plus a QR code that points to it.
The app is one Node process with a database file, so it needs a host that runs a Docker container (or Node 22.13+) all the time.
Static hosts (GitHub Pages, Netlify static) will **not** work.

> Tested here: the app, the 37 automated checks, production settings, the QR generator and the phone layout.
> **Not tested here:** the actual Docker build and the hosting services (no Docker or internet in the build environment).
> Do one full deployment test at least a week before the defense.

## Option A: Render (simplest, free plan available)
1. Create a GitHub repository and upload the project folder (the files in this zip). A private repo is fine.
2. Sign up at render.com, then **New > Blueprint** and pick the repository. Render reads `render.yaml`.
3. When asked, type a **strong LCMA_ADMIN_PASSWORD**. (`LCMA_SECRET` and `LCMA_DEVICE_KEY` are generated for you.)
4. Wait until the service shows **Live**. Your link looks like `https://lcma-prototype.onrender.com` (the name can differ; copy the real one).
5. Open the link on your phone and sign in as `student1@lcma.kz` / `Student#2026demo`.

Free-plan limits (check Render's current terms): the service **sleeps after about 15 minutes without visits** and needs up to a minute to wake;
and without a disk the **database resets on every restart or redeploy** (demo users and rooms are re-created automatically).
Before the defense: open the link 10 minutes early, and press Admin > Security > **Reset demo data** for a clean start.
For stable data and no sleeping, use a paid plan and uncomment the `disk:` block in `render.yaml`.

## Option B: Fly.io (keeps data on a volume)
```bash
fly launch --no-deploy --copy-config      # choose a unique app name when asked
fly volumes create lcma_data --size 1
fly secrets set LCMA_SECRET=$(openssl rand -hex 32) LCMA_ADMIN_PASSWORD='your-strong-password'
fly deploy
```
Your link is `https://<app-name>.fly.dev`.

## Option C: Your own server (any Linux VPS or university server with Docker)
```bash
cp .env.example .env          # fill in the values
docker compose up -d --build                         # http on port 3000
DOMAIN=lcma.example.com docker compose --profile https up -d --build   # automatic HTTPS for your domain
```
For HTTPS, point your domain's DNS at the server first. Close port 3000 to the public when you use the `https` profile.

## Make the QR code
After you have the final link:
```bash
node tools/qr.mjs https://your-app.onrender.com lcma-qr
```
This writes `lcma-qr.png` (for slides and posters) and `lcma-qr.svg` (best for printing at large size). The generator is built in and needs no installs.
Scan it with two different phones **on mobile data** (not the campus Wi-Fi) before printing.
Send the link to your teammate or to me and the QR can go straight into the A1 poster in the "Prototype" box.

## Settings (environment variables)
| Variable | Meaning | Default |
|---|---|---|
| `LCMA_SECRET` | Signs login tokens. Set a long random value, or users are signed out on every restart | random per start |
| `LCMA_ADMIN_PASSWORD` | Admin password, used when the database is first created | `Admin#2026demo` |
| `LCMA_STUDENT_PASSWORD` | Password of the two student accounts (if you change it, set `LCMA_DEMO_HINT=none`) | `Student#2026demo` |
| `LCMA_DEMO_HINT` | Sign-in page shows `all`, `student` only, or `none` of the demo logins | `all` locally, `student` in Docker |
| `LCMA_DEVICE_KEY` | Key that real sensors send in the `x-device-key` header to `POST /api/telemetry` | `demo-device-key` |
| `LCMA_TRUST_PROXY` | `1` behind a host or proxy so rate limits use the real visitor IP | off locally, `1` in Docker |
| `LCMA_SIM` | `0` turns the telemetry simulator off | on |
| `DB_PATH` | Database file location (put it on a volume) | `lcma.db`, `/data/lcma.db` in Docker |
| `PORT` | Port to listen on | `3000` |

## Safety notes for a public demo
- The admin password set on the host is not shown anywhere. The **student** demo login is shown on purpose, so visitors can try the app.
- Everything in the app is fictional. Do not enter real names, emails or passwords.
- Anyone with the link can create bookings and press buttons in the student view. Use **Reset demo data** to clean up.
- Login attempts are limited (5 wrong passwords per minute per visitor), and sessions last 1 hour.
- There are no backups in this prototype. This is a demo, not a production system.

## Pre-defense checklist
1. Deployed and opened on a phone over mobile data.
2. QR printed and scanned from the printed poster, not only from the screen.
3. Admin: Reset demo data. Student: apply for a room. Admin: approve it.
4. Dashboard chart is moving; Security tab > Simulate empty room shows HVAC switching to ECO.
5. Backup: the app also runs locally (`node server.js`) and you have the demo video.
